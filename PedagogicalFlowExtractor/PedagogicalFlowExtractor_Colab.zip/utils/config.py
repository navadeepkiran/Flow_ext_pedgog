"""Configuration management for PedagogicalFlowExtractor."""

import os
import yaml


_BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
_DEFAULT_CONFIG_PATH = os.path.join(_BASE_DIR, "config.yaml")


def load_config(config_path: str = None) -> dict:
    """Load YAML configuration file.

    Args:
        config_path: Path to config file. Defaults to project root config.yaml.

    Returns:
        Configuration dictionary.
    """
    path = config_path or _DEFAULT_CONFIG_PATH
    with open(path, "r", encoding="utf-8") as f:
        return yaml.safe_load(f)


def get_project_root() -> str:
    """Return the absolute path to the project root directory."""
    return _BASE_DIR


def resolve_path(relative_path: str) -> str:
    """Resolve a path relative to the project root."""
    return os.path.join(_BASE_DIR, relative_path)
